
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

app = FastAPI()

@app.post("/gerar-link")
async def gerar_link(request: Request):
    data = await request.json()
    print("Recebido:", data)
    return {"status": "ok", "link": "https://exemplo.com/link-simulado"}
